                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:1555724
Spiral staircase display stand e.g. for chess sets by dsb007 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Edit:  Added a solid model of the whole chess stand.  I don't think this will be easy to print but will look at a simpler model that will print in the future if there's enough interest, let me know.

I recently made a chess set (http://www.thingiverse.com/thing:1508763) and wanted to be able to display it without taking up too much shelf space.

I liked the stand by SteedMaker (http://www.thingiverse.com/thing:580331) but it was too modern and organic for my more 'gothic-esque' chess set so I designed this spiral staircase stand.

It is modular for easy printing and can be modified to your preference of steps, colour, column style or cap stone...my favorite is the knights helmet using the optional column supports and 6 steps to display each main piece once.  

If you have 6 steps it will balance, but suggest you use the optional support columns which attaches to the 'step with column support'; this gives extra stability especially for expensive/heavy chess pieces. 

You don't have to use it to just display chess sets!

If you want to fix the steps in place insert some 1.75 pla into one of the small holes on top of the step.  This will index with a small notch on the bottom of the step to lock in place.  Without this locking piece the steps can spin for 'free style'. 

Assembly is pretty intuitive.

Ive included the twist and lock mechanism as a Sketchup file so you can make your own mods.

For the flag pole I used 3mm pla.

You don't have to print all the files uploaded you can mix and match.  To make the design in the main photo print:
5 x steps with column support
1 x step without column support (this is the first step)
6 x main column round
1 x main column base
All support columns
1 x fluted spacer
The knights helmet

# Print Settings

Printer Brand: Printrbot
Printer: Simple Black
Rafts: No
Supports: Yes
Resolution: 0.2
Infill: 20%

Notes: 
I only use supports on the tongue of the twist and lock mechanism, the internals are covered with decent bridging.
The diameters of the twist and lock were sized to allow for shrinkage.  This works well on my printer but there may be tight or loose on other printers.  You can either resize/file a bit to accommodate or just glue in place.